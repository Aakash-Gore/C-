
#include<simplecpp>



int fn(long long x, unsigned long n, int k)
{
	int ans = 1;
	x = x % k;

	if (x == 0) return 0;

	while (n > 0)
	{

		if (n & 1)
			ans = (ans*x) % k;


		n= n>>1;
		x = (x*x) % k;
	}
	return ans;
}


main_program
{
	int x,n,k;
	cin>>x>>n>>k;
	cout << fn(x, n, k);

}
